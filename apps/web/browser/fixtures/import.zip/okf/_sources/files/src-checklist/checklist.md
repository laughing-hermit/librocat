# Restore checklist

1. Export the library.
2. Import it into the new one.
