---
type: Note
title: Imported note
description: A note that came in from an export.
tags: [import]
---

This note came in from a zip that Export made.
