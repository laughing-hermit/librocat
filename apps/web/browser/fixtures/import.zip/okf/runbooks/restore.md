---
type: Runbook
title: Restore a library
description: Import the zip that Export made.
tags: [import, ops]
---

1. Export the library.
2. Import the zip into another one.
