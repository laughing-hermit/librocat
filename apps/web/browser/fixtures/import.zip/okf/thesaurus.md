---
type: Thesaurus
title: Thesaurus
terms:
  ops:
    scope_note: Running the service.
---
